import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        while (true) {
            Train b1 = new Train();
            b1.setMobilenumber("01537120393");
            b1.setPass("Liza");
            String a = b1.getMobilenumber();
            String ww = b1.getPass();
            Scanner ac = new Scanner(System.in);
            System.out.println("Enter Your Mobile Number: ");
            String i = ac.nextLine();
            System.out.println("Enter The PassWord: ");
            String j = ac.next();
            int x = a.compareTo(i);
            int y = ww.compareTo(j);
            if (x == 0 && y == 0) {
                Train s1 = new Train();
                s1.log();
                System.out.println("Welcome To  Bangladesh Railway");

                s1.Trainlist();

                System.out.println("Enter the Choice? ");
                int ch = ac.nextInt();
                if (ch == 1 || ch==2 || ch==3 || ch==4) {
                    System.out.println("From: ");
                    String f = ac.next();
                    System.out.println("TO: ");
                    String t = ac.next();
                    System.out.println("Total Seat - 32");
                    System.out.println("Enter the Number Of passanger: ");
                    int s = ac.nextInt();
                    if (s <= 32) {
                        System.out.println("Enter the Passanger Name: ");
                        String na = ac.next();
                        System.out.println("Select Payment Option: ");
                        System.out.println("1.Bkash\n2.Nagod\n3.Rocket");
                        int cho = ac.nextInt();

                        System.out.println("Enter Your Number");
                        String nn = ac.next();
                        System.out.println("Enter the  Otp");
                        int o = ac.nextInt();
                        System.out.println("Enter Your Password: ");
                        int p = ac.nextInt();
                        System.out.println("Your Ticket is Confirm");
                        System.out.println("1.Download  Your Ticket\n2.Exit");
                        System.out.println("Choice: ");
                        int ci = ac.nextInt();
                        if (ci == 1) {
                            System.out.println("__________________________________");
                            System.out.println("From: " + f + "  TO: " + t);
                            System.out.println("Name: " + na);
                            System.out.println("Ticket Price :" + 450 * s + " taka");
                            System.out.println("Mobile Number: " + nn);
                            System.out.println("__________Thanks You - Bangladesh Railway______");
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            } else {
                Login l1 = new Login();
                l1.log();

            }

        }
    }
}


public class Login {
    private String Mobilenumber;
    private String pass;

    public String getMobilenumber() {
        return Mobilenumber;
    }

    public void setMobilenumber(String mobilenumber) {
        Mobilenumber = mobilenumber;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    void log()
    {
        System.out.println("Invalid passWord!Try again");
    }
}

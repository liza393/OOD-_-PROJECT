import java.util.Scanner;

public class Train extends Login {

        Scanner ac = new Scanner(System.in);

        void Trainlist()
        {
            System.out.println("1.Upukol Express");
            System.out.println("2.Ekota Express");
            System.out.println("3.Lalmoni Express");
            System.out.println("4.Turna Express");
        }
        void log()
        {
            System.out.println("Login Successfully");
        }


    }

